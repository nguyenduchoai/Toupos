<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Company/Author/Developer/Licence information of the application
    |--------------------------------------------------------------------------
    |
    | All details about the author/developer/contact/licence of the application
    |
    | IMPORTANT: CHANGING ANY OF THIS INFORMATION WILL UNSTABILIZE THE APPLICATION
    |
    */

    'vendor' => 'Ultimate Fosters',
    'vendor_url' => 'http://ultimatefosters.com',
    'email' => 'thewebfosters@gmail.com',
    'app_version' => "2.16.3",
    'lic1' => 'aHR0cHM6Ly9sLnVsdGltYXRlZm9zdGVycy5jb20vYXBpL3R5cGVfMQ==',
    'pid' => 1,
];
