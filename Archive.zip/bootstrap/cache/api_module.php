<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Api\\Providers\\ApiServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Api\\Providers\\ApiServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);