<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '1.1',
    'pid' => 4
];
