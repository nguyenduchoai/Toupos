<?php echo app('translator')->getFromJson('business.business'); ?>:
<address>
    <strong><?php echo e($transaction->business->name); ?></strong>
    <?php echo e($transaction->location->name ?? ''); ?>

    <?php if(!empty($transaction->location->landmark)): ?>
        <br><?php echo e($transaction->location->landmark); ?>

    <?php endif; ?>
    <?php if(!empty($transaction->location->city) || !empty($transaction->location->state) || !empty($transaction->location->country)): ?>
        <br><?php echo e(implode(',', array_filter([$transaction->location->city, $transaction->location->state, $transaction->location->country]))); ?>

    <?php endif; ?>
  
    <?php if(!empty($transaction->business->tax_number_1)): ?>
        <br><?php echo e($transaction->business->tax_label_1); ?>: <?php echo e($transaction->business->tax_number_1); ?>

    <?php endif; ?>

    <?php if(!empty($transaction->business->tax_number_2)): ?>
        <br><?php echo e($transaction->business->tax_label_2); ?>: <?php echo e($transaction->business->tax_number_2); ?>

    <?php endif; ?>

    <?php if(!empty($transaction->location->mobile)): ?>
        <br><?php echo app('translator')->getFromJson('contact.mobile'); ?>: <?php echo e($transaction->location->mobile); ?>

    <?php endif; ?>
    <?php if(!empty($transaction->location->email)): ?>
        <br><?php echo app('translator')->getFromJson('business.email'); ?>: <?php echo e($transaction->location->email); ?>

    <?php endif; ?>
</address>