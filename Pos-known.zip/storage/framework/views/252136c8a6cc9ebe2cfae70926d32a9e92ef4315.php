<div class="table-responsive">
    <table class="table table-bordered table-striped ajax_view table-text-center" id="product_table">
        <thead>
            <tr>
                <th><input type="checkbox" id="select-all-row"></th>
                <th>&nbsp;</th>
                <th><?php echo app('translator')->getFromJson('sale.product'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.selling_price'); ?></th>
                <th><?php echo app('translator')->getFromJson('report.current_stock'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.product_type'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.category'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.sub_category'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.brand'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.tax'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.sku'); ?></th>
                <th><?php echo app('translator')->getFromJson('messages.action'); ?></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <td colspan="11">
                <div style="display: flex; width: 100%;">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.delete')): ?>
                        <?php echo Form::open(['url' => action('ProductController@massDestroy'), 'method' => 'post', 'id' => 'mass_delete_form' ]); ?>

                        <?php echo Form::hidden('selected_rows', null, ['id' => 'selected_rows']);; ?>

                        <?php echo Form::submit(__('lang_v1.delete_selected'), array('class' => 'btn btn-xs btn-danger', 'id' => 'delete-selected')); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.update')): ?>
                    &nbsp;
                        <?php echo Form::open(['url' => action('ProductController@bulkEdit'), 'method' => 'post', 'id' => 'bulk_edit_form' ]); ?>

                        <?php echo Form::hidden('selected_products', null, ['id' => 'selected_products_for_edit']);; ?>

                        <button type="submit" class="btn btn-xs btn-primary" id="edit-selected"> <i class="fa fa-edit"></i><?php echo e(__('lang_v1.bulk_edit')); ?></button>
                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                    &nbsp;
                    <?php echo Form::open(['url' => action('ProductController@massDeactivate'), 'method' => 'post', 'id' => 'mass_deactivate_form' ]); ?>

                    <?php echo Form::hidden('selected_products', null, ['id' => 'selected_products']);; ?>

                    <?php echo Form::submit(__('lang_v1.deactivate_selected'), array('class' => 'btn btn-xs btn-warning', 'id' => 'deactivate-selected')); ?>

                    <?php echo Form::close(); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.deactive_product_tooltip') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                    </div>
                </td>
            </tr>
        </tfoot>
    </table>
</div>