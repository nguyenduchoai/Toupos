<div class="row">
    <div class="col-md-12">
        <?php $__env->startComponent('components.widget', ['title' => __('lang_v1.more_info')]); ?>
            <?php echo $__env->make('user.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->renderComponent(); ?>
    </div>
</div>
