<?php $__env->startSection('title', config('app.name', 'ultimatePOS')); ?>

<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
                margin-top: 10%;
            }
        .title {
                font-size: 84px;
            }
        .tagline {
                font-size:25px;
                font-weight: 300;
                text-align: center;
            }
    </style>
    <div class="title flex-center" style="font-weight: 600 !important;">
        <?php echo e(config('app.name', 'ultimatePOS')); ?>

    </div>
    <p class="tagline">
        <?php echo e(env('APP_TITLE', '')); ?>

    </p>
<?php $__env->stopSection(); ?>
            
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>