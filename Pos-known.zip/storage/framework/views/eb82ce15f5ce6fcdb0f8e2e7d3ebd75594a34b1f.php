<div class="box <?php echo e($class ?? 'box-solid'); ?>" <?php if(!empty($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?>>
    <?php if(empty($header)): ?>
        <?php if(!empty($title) || !empty($tool)): ?>
        <div class="box-header">
            <?php echo e($icon ?? ''); ?>

            <h3 class="box-title"><?php echo e($title ?? ''); ?></h3>
            <?php echo e($tool ?? ''); ?>

        </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="box-header">
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>

    <div class="box-body">
        <?php echo e($slot); ?>

    </div>
    <!-- /.box-body -->
</div>