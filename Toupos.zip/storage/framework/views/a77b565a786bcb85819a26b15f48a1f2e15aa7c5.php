<?php $__env->startSection('title', __('contact.view_contact')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header no-print">
    <h1><?php echo e(__('contact.view_contact')); ?></h1>
</section>

<!-- Main content -->
<section class="content no-print">
	<div class="box">
        <div class="box-header">
        	<h3 class="box-title">
                <i class="fa fa-user margin-r-5"></i>
                <?php if($contact->type == 'both'): ?> 
                    <?php echo app('translator')->getFromJson( 'contact.contact_info', ['contact' => __('contact.contact') ]); ?>
                <?php else: ?>
                    <?php echo app('translator')->getFromJson( 'contact.contact_info', ['contact' => ucfirst($contact->type) ]); ?>
                <?php endif; ?>
            </h3>
        </div>
        <div class="box-body">
            <span id="view_contact_page"></span>
            <div class="row">
                <div class="col-sm-3">
                    <div class="well well-sm">
                        <strong><?php echo e($contact->name); ?></strong><br><br>
                        <strong><i class="fa fa-map-marker margin-r-5"></i> <?php echo app('translator')->getFromJson('business.address'); ?></strong>
                        <p class="text-muted">
                            <?php if($contact->landmark): ?>
                                <?php echo e($contact->landmark); ?>

                            <?php endif; ?>

                            <?php echo e(', ' . $contact->city); ?>


                            <?php if($contact->state): ?>
                                <?php echo e(', ' . $contact->state); ?>

                            <?php endif; ?>
                            <br>
                            <?php if($contact->country): ?>
                                <?php echo e($contact->country); ?>

                            <?php endif; ?>
                        </p>
                        <?php if($contact->supplier_business_name): ?>
                            <strong><i class="fa fa-briefcase margin-r-5"></i> 
                            <?php echo app('translator')->getFromJson('business.business_name'); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->supplier_business_name); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm">
                        <strong><i class="fa fa-mobile margin-r-5"></i> <?php echo app('translator')->getFromJson('contact.mobile'); ?></strong>
                        <p class="text-muted">
                            <?php echo e($contact->mobile); ?>

                        </p>
                        <?php if($contact->landline): ?>
                            <strong><i class="fa fa-phone margin-r-5"></i> <?php echo app('translator')->getFromJson('contact.landline'); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->landline); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($contact->alternate_number): ?>
                            <strong><i class="fa fa-phone margin-r-5"></i> <?php echo app('translator')->getFromJson('contact.alternate_contact_number'); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->alternate_number); ?>

                            </p>
                        <?php endif; ?>

                        <?php if(!empty($contact->custom_field1)): ?>
                            <strong><?php echo app('translator')->getFromJson('lang_v1.custom_field', ['number' => 1]); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->custom_field1); ?>

                            </p>
                        <?php endif; ?>

                        <?php if(!empty($contact->custom_field2)): ?>
                            <strong><?php echo app('translator')->getFromJson('lang_v1.custom_field', ['number' => 2]); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->custom_field2); ?>

                            </p>
                        <?php endif; ?>

                        <?php if(!empty($contact->custom_field3)): ?>
                            <strong><?php echo app('translator')->getFromJson('lang_v1.custom_field', ['number' => 3]); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->custom_field3); ?>

                            </p>
                        <?php endif; ?>

                        <?php if(!empty($contact->custom_field4)): ?>
                            <strong><?php echo app('translator')->getFromJson('lang_v1.custom_field', ['number' => 4]); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->custom_field4); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if( $contact->type != 'customer'): ?>
                    <div class="col-sm-3">
                        <div class="well well-sm">
                            <strong><i class="fa fa-info margin-r-5"></i> <?php echo app('translator')->getFromJson('contact.tax_no'); ?></strong>
                            <p class="text-muted">
                                <?php echo e($contact->tax_number); ?>

                            </p>
                            <?php if($contact->pay_term_type): ?>
                                <strong><i class="fa fa-calendar margin-r-5"></i> <?php echo app('translator')->getFromJson('contact.pay_term_period'); ?></strong>
                                <p class="text-muted">
                                    <?php echo e(ucfirst($contact->pay_term_type)); ?>

                                </p>
                            <?php endif; ?>
                            <?php if($contact->pay_term_number): ?>
                                <strong><i class="fa fa-handshake-o margin-r-5"></i> <?php echo app('translator')->getFromJson('contact.pay_term'); ?></strong>
                                <p class="text-muted">
                                    <?php echo e($contact->pay_term_number); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-sm-3">
                    <div class="well well-sm">
                    <?php if( $contact->type == 'supplier' || $contact->type == 'both'): ?>
                        <strong><?php echo app('translator')->getFromJson('report.total_purchase'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->total_purchase); ?></span>
                        </p>
                        <strong><?php echo app('translator')->getFromJson('contact.total_purchase_paid'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->purchase_paid); ?></span>
                        </p>
                        <strong><?php echo app('translator')->getFromJson('contact.total_purchase_due'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->total_purchase - $contact->purchase_paid); ?></span>
                        </p>
                    <?php endif; ?>
                    <?php if( $contact->type == 'customer' || $contact->type == 'both'): ?>
                        <strong><?php echo app('translator')->getFromJson('report.total_sell'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->total_invoice); ?></span>
                        </p>
                        <strong><?php echo app('translator')->getFromJson('contact.total_sale_paid'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->invoice_received); ?></span>
                        </p>
                        <strong><?php echo app('translator')->getFromJson('contact.total_sale_due'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->total_invoice - $contact->invoice_received); ?></span>
                        </p>
                    <?php endif; ?>
                    <?php if(!empty($contact->opening_balance) && $contact->opening_balance != '0.00'): ?>
                        <strong><?php echo app('translator')->getFromJson('lang_v1.opening_balance'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->opening_balance); ?></span>
                        </p>
                        <strong><?php echo app('translator')->getFromJson('lang_v1.opening_balance_due'); ?></strong>
                        <p class="text-muted">
                        <span class="display_currency" data-currency_symbol="true">
                        <?php echo e($contact->opening_balance - $contact->opening_balance_paid); ?></span>
                        </p>
                    <?php endif; ?>
                    </div>
                </div>
                <?php if($reward_enabled): ?>
                    <div class="clearfix"></div>
                    <div class="col-md-3">
                        <div class="info-box bg-yellow">
                            <span class="info-box-icon"><i class="fa fa-gift"></i></span>

                            <div class="info-box-content">
                              <span class="info-box-text"><?php echo e(session('business.rp_name')); ?></span>
                              <span class="info-box-number"><?php echo e($contact->total_rp ?? 0); ?></span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                    </div>
                <?php endif; ?>
                <?php if( $contact->type == 'supplier' || $contact->type == 'both'): ?>
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                        <?php if(($contact->total_purchase - $contact->purchase_paid) > 0): ?>
                            <a href="<?php echo e(action('TransactionPaymentController@getPayContactDue', [$contact->id])); ?>?type=purchase" class="pay_purchase_due btn btn-primary btn-sm pull-right"><i class="fa fa-money" aria-hidden="true"></i> <?php echo app('translator')->getFromJson("contact.pay_due_amount"); ?></a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- list purchases -->

    <?php
        $transaction_types = [];
        if(in_array($contact->type, ['both', 'supplier'])){
            $transaction_types['purchase'] = __('lang_v1.purchase');
            $transaction_types['purchase_return'] = __('lang_v1.purchase_return');
        }

        if(in_array($contact->type, ['both', 'customer'])){
            $transaction_types['sell'] = __('sale.sale');
            $transaction_types['sell_return'] = __('lang_v1.sell_return');
        }

        $transaction_types['opening_balance'] = __('lang_v1.opening_balance');
    ?>

    <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => __('lang_v1.ledger')]); ?>
        <div class="row">
            <div class="col-md-12">
                <?php $__currentLoopData = $transaction_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="form-group">
                            <div class="checkbox">
                                <label>
                                  <?php echo Form::checkbox('transaction_types[]', $key, true, 
                                  [ 'class' => 'input-icheck transaction_types']);; ?> <?php echo e($value); ?>

                                </label>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div class="col-md-3">
                    <div class="form-group">
                        <div class="checkbox">
                            <label>
                              <?php echo Form::checkbox('show_payments', 1, true, 
                              [ 'class' => 'input-icheck', 'id' => 'show_payments']);; ?> <?php echo app('translator')->getFromJson('lang_v1.show_payments'); ?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-3">
                    <div class="form-group">
                        <?php echo Form::label('ledger_date_range', __('report.date_range') . ':'); ?>

                        <?php echo Form::text('ledger_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']);; ?>

                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div id="contact_ledger_div"></div>
            </div>
        </div>
    <?php echo $__env->renderComponent(); ?>

    <?php if( in_array($contact->type, ['customer', 'both']) && session('business.enable_rp')): ?>
        <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => session('business.rp_name')]); ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped" 
                id="rp_log_table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('messages.date'); ?></th>
                            <th><?php echo app('translator')->getFromJson('sale.invoice_no'); ?></th>
                            <th><?php echo app('translator')->getFromJson('lang_v1.earned'); ?></th>
                            <th><?php echo app('translator')->getFromJson('lang_v1.redeemed'); ?></th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
</section>
<!-- /.content -->
<div class="modal fade payment_modal" tabindex="-1" role="dialog" 
        aria-labelledby="gridSystemModalLabel">
</div>
<div class="modal fade edit_payment_modal" tabindex="-1" role="dialog" 
    aria-labelledby="gridSystemModalLabel">
</div>
<div class="modal fade pay_contact_due_modal" tabindex="-1" role="dialog" 
        aria-labelledby="gridSystemModalLabel"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready( function(){
    $('#ledger_date_range').daterangepicker(
        dateRangeSettings,
        function (start, end) {
            $('#ledger_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
        }
    );
    $('#ledger_date_range').change( function(){
        get_contact_ledger();
    });
    get_contact_ledger();

    rp_log_table = $('#rp_log_table').DataTable({
        processing: true,
        serverSide: true,
        aaSorting: [[0, 'desc']],
        ajax: '/sells?customer_id=<?php echo e($contact->id); ?>&rewards_only=true',
        columns: [
            { data: 'transaction_date', name: 'transactions.transaction_date'  },
            { data: 'invoice_no', name: 'transactions.invoice_no'},
            { data: 'rp_earned', name: 'transactions.rp_earned'},
            { data: 'rp_redeemed', name: 'transactions.rp_redeemed'},
        ]
    });
});

$("input.transaction_types, input#show_payments").on('ifChanged', function (e) {
    get_contact_ledger();
});

function get_contact_ledger() {

    var start_date = '';
    var end_date = '';
    var transaction_types = $('input.transaction_types:checked').map(function(i, e) {return e.value}).toArray();
    var show_payments = $('input#show_payments').is(':checked');

    if($('#ledger_date_range').val()) {
        start_date = $('#ledger_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD');
        end_date = $('#ledger_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD');
    }
    $.ajax({
        url: '/contacts/ledger?contact_id=<?php echo e($contact->id); ?>&start_date=' + start_date + '&transaction_types=' + transaction_types + '&show_payments=' + show_payments + '&end_date=' + end_date,
        dataType: 'html',
        success: function(result) {
            $('#contact_ledger_div')
                .html(result);
            __currency_convert_recursively($('#ledger_table'));

            $('#ledger_table').DataTable({
                searchable: false,
                ordering:false
            });
        },
    });
}
</script>
<script src="<?php echo e(asset('js/payment.js?v=' . $asset_v)); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>