<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '1.0',
    'pid' => 4
];
